#!/bin/bash

CCA_HOME=/opt/cca
VAR_DIR=/var/lib/cca

CCA_SCRIPTS_DIR=${CCA_HOME}/scripts
DB_DIR=${VAR_DIR}/db
DD_DIR=${VAR_DIR}/dd
UNPARSED_PROJECTS_DIR=${VAR_DIR}/unparsed-projects
