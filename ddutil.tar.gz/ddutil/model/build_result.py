
class BuildResult(object):
    def __init__(self,err_set,rcids) -> None:
        self.err_set = err_set
        self.rcids = rcids