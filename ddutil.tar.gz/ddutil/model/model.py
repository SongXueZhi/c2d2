LOG_MODEL="log"
MATRIX_MODEL="matrix"
LOG_MATRIX_MODEL="log+matrix"
NON_MODEL="non"
